# HAND-WRITTEN DIGIT RECOGNITION

-Run the code from src/Main.java. A GUI 
should appear with all the necessary 
features.
